// Data mahasiswa yang sudah terdaftar (nama dan NRP)
const mahasiswa = [
    { nama: "Agus",  nrp: "5025251101" },
    { nama: "Budi",  nrp: "5025251102" },
    { nama: "Asep",  nrp: "5025251103" },
    { nama: "Bunga", nrp: "5025251104" },
    { nama: "Lisa",  nrp: "5025251105" },
    { nama: "Rena",  nrp: "5025251106" }
];

// Mata kuliah Semester 3 dan dosen pengampunya
const mataKuliah = {
    "Jaringan Komputer": [
        "Bagus Jati Santoso, S.Kom., Ph.D.",
        "Prof. Ir. Ary Mazharuddin Shiddiqi, S.Kom., M.Comp.Sc., Ph.D.",
        "Royyana Muslim Ijtihadie, S.Kom., M.Kom., Ph.D."
    ],
    "Konsep Kecerdasan Artifisial": [
        "Prof. Dr. Eng. Nanik Suciati, S.Kom., M.Kom."
    ],
    "Konsep Pengembangan Perangkat Lunak": [
        "Bintang Nuralamsyah, S.Kom., M.Kom.",
        "Dr. Sarwosri, S.Kom., M.T."
    ],
    "Matematika Diskrit": [
        "Muhamad Hilmil Muchtar Aditya Pradana, S.Kom., M.Sc., Ph.D."
    ],
    "Pemrograman Berorientasi Objek": [
        "Ir. Misbakhul Munir Irfan Subakti, S.Kom., M.Sc., M.Phil."
    ],
    "Pemrograman Web": [
        "Fajar Baskoro, S.Kom., M.T."
    ],
    "Teori Graf": [
        "Victor Hariadi, S.Si., M.Kom."
    ]
};

// Elemen form dan input
const form        = document.getElementById("formRegistrasi");
const inputNama   = document.getElementById("nama");
const inputNrp    = document.getElementById("nrp");
const inputMatkul = document.getElementById("matkul");
const inputDosen  = document.getElementById("dosen");
const inputSetuju = document.getElementById("setuju");

function matkulValid() {
    return Object.hasOwn(mataKuliah, inputMatkul.value);
}

function daftarDosen() {
    return matkulValid() ? mataKuliah[inputMatkul.value] : [];
}

// Fungsi rekomendasi untuk input teks
function pasangRekomendasi({ input, daftar, ambilData, saatDipilih,
                            dariAwal = false, munculSaatKosong = false }) {

    function tampilkan() {
        const kata = input.value.trim().toLowerCase();

        if (kata === "" && !munculSaatKosong) {
            daftar.hidden = true;
            return;
        }

        const cocok = ambilData().filter(function (item) {
            const teks = item.toLowerCase();
            return dariAwal ? teks.startsWith(kata) : teks.includes(kata);
        });

        daftar.innerHTML = "";

        if (cocok.length === 0) {
            daftar.hidden = true;
            return;
        }

        cocok.forEach(function (item) {
            const li = document.createElement("li");
            li.textContent = item;
            li.addEventListener("mousedown", function () {
                input.value = item;
                daftar.hidden = true;
                saatDipilih(item);
            });
            daftar.appendChild(li);
        });

        daftar.hidden = false;
    }

    input.addEventListener("input", tampilkan);
    input.addEventListener("focus", tampilkan);
    input.addEventListener("blur", function () {
        daftar.hidden = true;
    });
}

// Dosen sesuai dengan mata kuliah yang dipilih
function aturDosen() {
    const valid = matkulValid();
    inputDosen.disabled = !valid;
    inputDosen.value = "";
    inputDosen.placeholder = valid
        ? "Pilih atau ketik nama dosen"
        : "Pilih mata kuliah terlebih dahulu";
}

inputMatkul.addEventListener("input", aturDosen);

// NRP: OTOMATIS KALAU NAMA ADA DI DATA, MANUAL KALAU TIDAK
let nrpOtomatis = false;   // true kalau isi NRP berasal dari data, bukan ketikan sendiri

inputNama.addEventListener("input", function () {
    const kata = inputNama.value.trim().toLowerCase();
    const cocok = mahasiswa.find(function (m) { return m.nama.toLowerCase() === kata; });

    if (cocok) {
        inputNrp.value = cocok.nrp;
        nrpOtomatis = true;
    } else if (nrpOtomatis) {
        inputNrp.value = "";     // nama diganti: hapus NRP milik orang sebelumnya
        nrpOtomatis = false;
    }
});

inputNrp.addEventListener("input", function () {
    nrpOtomatis = false;        
});

// Penempatan fungsi rekomendasi untuk input nama, mata kuliah, dan dosen
pasangRekomendasi({
    input: inputNama,
    daftar: document.getElementById("saranNama"),
    ambilData: function () {
        return mahasiswa.map(function (m) { return m.nama; });
    },
    dariAwal: true,
    munculSaatKosong: false,
    saatDipilih: function (nama) {
        const data = mahasiswa.find(function (m) { return m.nama === nama; });
        inputNrp.value = data.nrp;
        nrpOtomatis = true;
    }
});

pasangRekomendasi({
    input: inputMatkul,
    daftar: document.getElementById("saranMatkul"),
    ambilData: function () { return Object.keys(mataKuliah); },
    munculSaatKosong: true,
    saatDipilih: aturDosen
});

pasangRekomendasi({
    input: inputDosen,
    daftar: document.getElementById("saranDosen"),
    ambilData: daftarDosen,
    munculSaatKosong: true,
    saatDipilih: function () {}
});

// SUBMIT, VALIDASI, DAFTAR TERDAFTAR 
const kotakHasil  = document.getElementById("hasil");
const tabel       = document.getElementById("tabel");
const isiTabel    = document.getElementById("isiTabel");
const pesanKosong = document.getElementById("kosong");
const jumlah      = document.getElementById("jumlah");

// Tempat menyimpan data yang sudah mendaftar (hilang kalau halaman di-refresh)
const pendaftar = [];

const semuaError = ["errorNama", "errorNrp", "errorMatkul", "errorDosen", "errorSetuju"];

function isiError(id, pesan) {
    document.getElementById(id).textContent = pesan;
}

// Tombol Reset: kosongkan error dan kembalikan kolom dosen ke keadaan awal.
form.addEventListener("reset", function () {
    setTimeout(function () {
        aturDosen();
        nrpOtomatis = false;
        semuaError.forEach(function (id) { isiError(id, ""); });
    }, 0);
});

function validasi() {
    let valid = true;
    semuaError.forEach(function (id) { isiError(id, ""); });

    if (inputNama.value.trim() === "") {
        isiError("errorNama", "Nama wajib diisi.");
        valid = false;
    }

    if (!/^\d{10}$/.test(inputNrp.value.trim())) {
        isiError("errorNrp", "NRP harus terdiri dari 10 digit angka.");
        valid = false;
    }

    if (!matkulValid()) {
        isiError("errorMatkul", "Pilih mata kuliah dari daftar.");
        valid = false;
    } else if (!daftarDosen().includes(inputDosen.value)) {
        isiError("errorDosen", "Pilih dosen dari daftar.");
        valid = false;
    }

    if (!inputSetuju.checked) {
        isiError("errorSetuju", "Centang persetujuan dulu.");
        valid = false;
    }

    return valid;
}

function tampilkanHasil(pesan, jenis) {
    kotakHasil.textContent = pesan;
    kotakHasil.className = jenis;   
    kotakHasil.hidden = false;
}

function gambarTabel() {
    isiTabel.innerHTML = "";

    pendaftar.forEach(function (p, urutan) {
        const baris = document.createElement("tr");

        [p.nama, p.nrp, p.matkul, p.dosen].forEach(function (isi) {
            const sel = document.createElement("td");
            sel.textContent = isi;
            baris.appendChild(sel);
        });

        const selAksi = document.createElement("td");
        const tombol = document.createElement("button");
        tombol.type = "button";
        tombol.className = "hapus";
        tombol.textContent = "Hapus";
        tombol.addEventListener("click", function () {
            pendaftar.splice(urutan, 1);
            gambarTabel();
        });
        selAksi.appendChild(tombol);
        baris.appendChild(selAksi);

        isiTabel.appendChild(baris);
    });

    jumlah.textContent = pendaftar.length;
    tabel.hidden = pendaftar.length === 0;
    pesanKosong.hidden = pendaftar.length > 0;
}

form.addEventListener("submit", function (e) {
    e.preventDefault();
    kotakHasil.hidden = true;

    if (!validasi()) return;

    const data = {
        nama:   inputNama.value.trim(),
        nrp:    inputNrp.value.trim(),
        matkul: inputMatkul.value,
        dosen:  inputDosen.value
    };

    // Cek apakah NRP ini sudah terdaftar di mata kuliah yang sama
    const sudahAda = pendaftar.some(function (p) {
        return p.nrp === data.nrp && p.matkul === data.matkul;
    });

    if (sudahAda) {
        tampilkanHasil(
            data.nama + " sudah terdaftar di " + data.matkul + ".",
            "gagal"
        );
        return;
    }

    pendaftar.push(data);
    gambarTabel();
    tampilkanHasil(
        data.nama + " berhasil mendaftar di " + data.matkul + ".",
        "sukses"
    );
    form.reset();   // event "reset" di atas yang mengurus aturDosen()
});